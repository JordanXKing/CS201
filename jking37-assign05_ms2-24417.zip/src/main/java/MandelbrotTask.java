import javax.print.attribute.standard.MediaSize.Other;

public class MandelbrotTask implements Runnable {
    private double x1, y1, x2, y2;
    private int startCol, endCol, startRow, endRow;
    private int[][] iterCounts;

	// TODO: Add constructor to set bounds for task
    public MandelbrotTask(double x1, double y1, double x2, double y2,
                          int startCol, int endCol, int startRow, int endRow,
                          int[][] iterCounts) {
    	this.x1 = x1;
    	this.x2 = x2;
    	this.y1 = y1;
    	this.y2 = y1;
    	this.startCol = startCol;
    	this.endCol = endCol;
    	this.startRow = startRow;
    	this.endRow = endRow;
    	this.iterCounts = iterCounts;
	}

	// Method to compute all iteration counts for region
	public void run() {
		// TODO: Loop over array extents to compute iterations for each point
		int computeIter;
		
		for (int i = 0; i < iterCounts.length; i++) {
			for(int j = 0; j < iterCounts.length; i++) {
				Complex c = getComplex(i, j);
				computeIter = computeIterCount(c);
				iterCounts[i][j] = computeIter;
			}
		}
	}

	// Method to determine the number of iterations beginning with value c
	private int computeIterCount(Complex c) {
		int count = 0;
		Complex z = new Complex(0, 0);
		// if z's magnitude is greater 2 or the number of iterations == 1,000
		// TODO: Iterate Mandelbrot equation up to MandelBrot.THRESHOLD
		
		while(z.getMagnitude() < 2 && count < Mandelbrot.THRESHOLD) {
			
			// (Zn)^2 + C being implemented
			c.add(z.mult(z));
			count++;
		 }
		return count;
	}
	
	// Method to determine the complex value from the bounds and array indicies
	private Complex getComplex(int row, int col) {
		Complex c;
		// setting up delta X and Y to have a more compact design
		double deltaX = (x2 - x1) / Mandelbrot.WIDTH;
		double deltaY = (y2 - y1) / Mandelbrot.HEIGHT;
		// TODO: Compute the complex value from the region bounds and
		//       the given array indicies
		 c = new Complex(x1 + (col*deltaX),(y2 - (row * deltaY)));
		return c;
	}
}
