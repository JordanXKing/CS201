import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.NoSuchElementException;

/**
 * Class to represent a pile of {@link Card}s.
 * Each card has an index, with index 0 being the card
 * at the bottom of the pile.
 * Each pile has an "expose index": all cards whose
 * indices are greater than or equal to the expose index
 * are face-up, and all other cards are face-down.
 */
public class Pile {
	// TODO: add fields
	private int exposeIndex;
	private ArrayList<Card> cards = new ArrayList<Card>();
	private Rank[] rank = Rank.values();
	private Suit[] suit = Suit.values();
	/**
	 * Constructor.  The pile will be empty initially,
	 * and its expose index will be set to 0.
	 */
	public Pile() {
		//throw new UnsupportedOperationException("TODO - implement");
		exposeIndex = 0;
	}

	/**
	 * @return the expose index
	 */
	public int getExposeIndex() {
		//throw new UnsupportedOperationException("TODO - implement");
		return exposeIndex;
	}
	
	/**
	 * Set the expose index.
	 * 
	 * @param exposeIndex the expose index to set
	 */
	public void setExposeIndex(int exposeIndex) {
		//throw new UnsupportedOperationException("TODO - implement");
		this.exposeIndex = exposeIndex;
	}
	
	/**
	 * Add a {@link Card} to the pile.  The card added is placed
	 * on top of the cards currently in the pile.
	 * 
	 * @param card the {@link Card} to add
	 */
	public void addCard(Card card) {
		//throw new UnsupportedOperationException("TODO - implement");
		cards.add(card);
	}

	/**
	 * @return the number of @{link Card}s in the pile
	 */
	public int getNumCards() {
		return cards.size();
	}
	
	/**
	 * @return true if the pile is empty, false otherwise
	 */
	public boolean isEmpty() {
		if (getNumCards() == 0) {
			return true;
		}else {
			return false;
		}
	}
	
	/**
	 * Get the {@link Card} whose index is given.
	 * 
	 * @param index the index of the card to get
	 * @return the {@link Card} at the index
	 * @throws NoSuchElementException if the index does not refer to a valid card
	 */
	public Card getCard(int index) {
		if (index < getNumCards() && index >= 0) {
			return cards.get(index);
		}else {
			throw new NoSuchElementException();
		}
	}

	/**
	 * Get the {@link Card} on top of the pile.
	 * 
	 * @return the {@link Card} on top of the pile
	 * @throws NoSuchElementException if the pile is empty
	 */
	public Card getTopCard() {
		if(isEmpty() == true) {
			throw new NoSuchElementException();
		}else {
			return getCard(getNumCards() - 1);
		}
	}
	
	/**
	 * @return the index of the top {@link Card}, or -1 if the pile is empty
	 */
	public int getIndexOfTopCard() {
		//checking if the pile is empty and then if false return the index of the top card
		if (isEmpty() == true) {
			return -1;
		}else {
			return getNumCards() - 1;
		}
	}
	
	/**
	 * Remove given number of {@link Card}s from the top of the pile.
	 * 
	 * @param numCards number of cards to remove
	 * @return an ArrayList containing the removed cards
	 * @throws IllegalArgumentException if the pile does not have enough {@link Card}s to satisfy the request
	 */
	public ArrayList<Card> removeCards(int numCards) {
		ArrayList<Card> removedCards = new ArrayList<Card>();
		// checking if the number of cards exceeds the amount within the arraylist
		if (getNumCards() < numCards) {
			throw new IllegalArgumentException();
		}else {
			//adding cards to removedCards and removing them from the array list
			for (int i = 1 ; i <= numCards; i++) {
				removedCards.add(0 ,cards.get(cards.size() - i));
			}
			cards.removeAll(removedCards);
			
			return removedCards;
		}
	}
	public ArrayList<Card> removeAll(int numCards) {
		ArrayList<Card> removedCards = new ArrayList<Card>();
		// checking if the number of cards exceeds the amount within the arraylist
		if (getNumCards() < numCards) {
			throw new IllegalArgumentException();
		}else {
			//adding cards to removedCards and removing them from the array list
			for (int i = 0 ; i < numCards; i++) {
				removedCards.add(cards.get(i));
			}
			cards.removeAll(removedCards);
			Collections.reverse(removedCards);
			return removedCards;
		}
	}
	/**
	 * Add {@link Card}s to the top of the pile.
	 * 
	 * @param cardsToAdd an ArrayList containing the {@link Card}s to add
	 */
	public void addCards(ArrayList<Card> cardsToAdd) {
		// adding cards to the arraylist
			cards.addAll(cardsToAdd);
		
	}
	
	/**
	 * Populate the pile by adding 52 {@link Card}s
	 * representing all possible combinations of
	 * {@link Suit} and {@link Rank}.
	 */
	public void populate() {
		// adding cards to the deck
		for(int i = 0; i < suit.length; i++) {
			for(int j = 0; j < rank.length; j++) {
				cards.add(new Card(rank[j], suit[i]));
			}
		}
	}

	/**
	 * Shuffle the {@link Card}s in the pile by rearranging
	 * them randomly.
	 */
	public void shuffle() {
		//shuffling the card objects within the arraylist
		Collections.shuffle(cards);
	}
	
	/**
	 * Remove the top {@link Card} on the pile and return it.
	 * 
	 * @return the removed {@link Card}
	 * @throws NoSuchElementException if the pile is empty
	 */
	public Card drawCard() {
		// checking if the pile is empty and then if false returning the removed card
		if (isEmpty() == true) {
			throw new NoSuchElementException();
		}
		return cards.remove(cards.size() - 1);
	}
}
