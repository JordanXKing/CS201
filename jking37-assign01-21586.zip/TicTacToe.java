import java.util.Scanner;

public class TicTacToe {
	public static final int PLAYER_X = 1;
	public static final int PLAYER_O = 2;
	
	public static void main(String[] args) {
		int[][] board = new int[3][3];
		
		Scanner keyboard = new Scanner(System.in);
		
		int player = PLAYER_X;
		boolean done = false;
		while (!done) {
			System.out.println();
			printBoard(board);
			
			System.out.printf("\nPlayer %c's turn:\n", (player == PLAYER_X) ? 'X' : 'O');
			int row = getRow(keyboard);
			int col = getCol(keyboard);
			
			if (!isLegalMove(board, row, col)) {
				System.out.println("Invalid move, try again");
			} else {
				placeMarker(board, row, col, player);
				if (playerWins(board, player)) {
					// Current player wins
					System.out.printf("Player %s wins!\n", player == PLAYER_X ? "X" : "O");
					done = true;
				} else if (isDraw(board)) {
					// Game is a draw
					System.out.println("It's a draw!");
					done = true;
				} else {
					// Switch player
					player = (player == PLAYER_X) ? PLAYER_O : PLAYER_X;
				}
			}
		}
		System.out.println("Thanks for playing!");
	}

	public static void printBoard(int[][] board) {
		for(int i = 0; i < 3; i++) {
			for (int j = 0; j < 3;j++) {
				if (board[i][j] == 0) {
					System.out.print("   ");
				}else if(board[i][j] == 1) {
					System.out.print(" X ");
				}else if(board[i][j] == 2) {
					System.out.print(" O ");
				}
				
				if(j == 0 || j == 1) {
					System.out.print("|");
				}
			}
			//System.out.println();
			if(i == 0 || i == 1) {
				System.out.println("");
				System.out.println("------------");
			}
			
		}
	}
	
	public static int getRow(Scanner keyboard) {
		//throw new UnsupportedOperationException("not implemented yet");
		System.out.println("Enter Row (0-2): ");
		String Row = keyboard.next();
		int i=Integer.parseInt(Row);
		return i;
	}

	public static int getCol(Scanner keyboard) {
		//throw new UnsupportedOperationException("not implemented yet");
		System.out.println("Enter column (0-2): ");
		String Col = keyboard.next();
		int i=Integer.parseInt(Col);
		return i;
	}

	public static boolean isLegalMove(int[][] board, int row, int col) {
		//throw new UnsupportedOperationException("not implemented yet");
		if( row <= 2 && col <= 2 && row >= 0 && col >= 0 && board[row][col] == 0) {
			return true;
		}else {
			return false;
		}
	}
	
	public static void placeMarker(int[][] board, int row, int col, int player) {
		//throw new UnsupportedOperationException("not implemented yet");
		if(player == PLAYER_X) {
			board[row][col] = 1;
		}else if(player == PLAYER_O) {
			board[row][col] = 2;
		}
	}

	public static boolean playerWins(int[][] board, int player) {
		// TODO: implement this for real
		if(board[0][0] == board[0][1] && board[0][0] == board[0][2]) {
			if(board[0][0] == player) {
				return true;
			}else {
				return false;
			}
		}else if (board[1][0] == board[1][1] && board[1][0] == board[1][2]) {
			if(board[1][0] == player) {
				return true;
			}else {
				return false;
			}
		}else if(board[2][0] == board[2][1] && board[2][0] == board[2][2]) {
			if(board[2][0] == player) {
				return true;
			}else {
				return false;
			}
		}else if (board[0][0] == board[1][1] && board[0][0] == board[2][2]) {
			if(board[0][0] == player) {
				return true;
			}else {
				return false;
			}
		}else if(board[0][2] == board[1][1] && board[0][2] == board[2][0]) {
			if(board[0][2] == player) {
				return true;
			}else {
				return false;
			}
		}else if(board[0][0] == board[1][0] && board[0][0] == board[2][0]) {
			if(board[0][0] == player) {
				return true;
			}else {
				return false;
			}
		}else if(board[0][1] == board[1][1] && board[0][1] == board[2][1]) {
			if(board[0][1] == player) {
				return true;
			}else {
				return false;
			}
		}else if(board[0][2] == board[1][2] && board[0][2] == board[2][2]) {
			if(board[0][2] == player) {
				return true;
			}else {
				return false;
			}
		}else {
			return false;
		}
		
	}

	public static boolean isDraw(int[][] board) {
		// TODO: implement this for real
		int draw = 0;
		for (int i = 0; i < 3; i++) {
			for(int j = 0; j < 3; j++) {
				if (board[i][j] == 0) {
					draw = 1;
				}
			}
		}
		if (draw == 1) {
			return false;
		}else {
			return true;
		}
		
	}
}
