package edu.ycp.cs201.disks;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.Random;

import javax.swing.JPanel;
import javax.swing.Timer;

public class DisksPanel extends JPanel {
	private static final long serialVersionUID = 1L;

	public static final int WIDTH = 400;
	public static final int HEIGHT = 300;
	private Timer timer;
	private int xMouse;
	private int yMouse;
	private int count = 0;
	ArrayList<Disk> Disks = new ArrayList<Disk>();
	private int random;
	private int Gameover = 0;
	private int timeBarLength = WIDTH;
	private Color color;

	Random rand;
	// TODO: add any other fields you need to represent the state of the game
	
	public DisksPanel() {
		setPreferredSize(new Dimension(WIDTH, HEIGHT));
		setBackground(Color.GRAY);
		rand = new Random();
		random = rand.ints(10,(44+1)).findFirst().getAsInt();
		
		addMouseListener(new MouseAdapter(){
			@Override
			public void mouseClicked(MouseEvent e) {
				xMouse = e.getX();
				yMouse = e.getY();
				
				// stops player action
				if (Gameover == 0) {
					handleMouseClick(e);
				}
				
				
			}
		});
		
		
		addMouseMotionListener(new MouseAdapter() {
			@Override
			public void mouseMoved(MouseEvent e) {
				handleMouseMove(e);
				xMouse = e.getX();
				yMouse = e.getY();
				
			}
		});
		
		// Schedule timer events to fire every 100 milliseconds (0.1 seconds)
		this.timer = new Timer(100, new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				timer.start();
				handleTimerEvent(e);
			}
		});
	}

	// You can call this method to convert a DiskColor value into
	// a java.awt.Color object.
	public Color colorOf(DiskColor dc) {
		return new Color(dc.red(), dc.green(), dc.blue());
	}

	// This method is called whenever the mouse is moved
	protected void handleMouseMove(MouseEvent e) {
		// TODO
		repaint();
	}
	
	// This method is called whenever the mouse is clicked
	protected void handleMouseClick(MouseEvent e) {
		// TODO

		Disk newDisk = new Disk(xMouse, yMouse, random, DiskColor.values()[rand.ints(1,(10+1)).findFirst().getAsInt()]);
		// Overlap check
		for(int i = 0; i < Disks.size(); i++) {
			if(newDisk.overlaps(Disks.get(i)) == true) {
				Gameover = 1;
			}
		}
		Disks.add(newDisk);
		
		// Out of bounds check
		if(newDisk.isOutOfBounds(WIDTH, HEIGHT) == true) {
			Gameover = 1;
		}
		
		count += 1;
		random = rand.ints(10,(44+1)).findFirst().getAsInt();
		
		repaint();
		timer.restart();
		timeBarLength = WIDTH;
	}
	
	// This method is called whenever a timer event fires
	protected void handleTimerEvent(ActionEvent e) {
		// TODO
		timeBarLength -= count;
		
		if(timeBarLength <= 0) {
			Gameover = 1;
		}
	
		repaint();
	}
	
	private static final Font FONT = new Font("Dialog", Font.BOLD, 24);

	// This method is called automatically whenever the contents of
	// the window need to be redrawned.
	@Override
	public void paintComponent(Graphics g) {
		// Paint the window background

		// cursor circle
		super.paintComponent(g);
		g.drawOval(xMouse - (random), yMouse - (random), random * 2, random * 2);
		
		// print Disks
		for(int i = 0;i < Disks.size(); i++) {
			g.setColor(colorOf(Disks.get(i).getColor()));
			g.fillOval((int)Disks.get(i).getX() - ((int)Disks.get(i).getRadius()), (int)Disks.get(i).getY() - ((int)Disks.get(i).getRadius()), (int)Disks.get(i).getRadius() * 2, (int)Disks.get(i).getRadius() * 2);
		}
			
		//Game over man! Game Over!
		if(Gameover == 1) {
			g.setColor(Color.BLACK);
			g.setFont(FONT);
			g.drawString("Game over!", (WIDTH / 3), (HEIGHT / 2));
			
			g.drawString("Score: " + count, (WIDTH / 3 + 20), ((HEIGHT / 2) + 50));
		}else {
			// Points
			g.setColor(Color.BLACK);
			g.setFont(FONT);
			g.drawString(Integer.toString(count), 325, 250);
			
			// The timer bar
			Color barColor = new Color(255, 23, 23, 63);
			g.setColor(barColor);
			g.fillRect(0, 265, timeBarLength, 20);
			
			
				
		}
	
		
		
		
		
		// TODO: draw everything that needs to be drawn
	}

	private void drawString(String counter2, int i, int j) {
		// TODO Auto-generated method stub
		
	}
}
